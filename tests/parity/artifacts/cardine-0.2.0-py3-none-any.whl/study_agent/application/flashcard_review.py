"""Learner-safe read DTOs for reviewing generated flashcard proposals."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import cast

from study_agent.artifacts.content import (
    AnswerBlock,
    HybridFlashcardContent,
    MorphologyFlashcardContent,
)
from study_agent.artifacts.contracts import (
    ArtifactBatchRecord,
    ArtifactRevisionRecord,
)
from study_agent.artifacts.identity import GeneratedArtifactProvenance
from study_agent.domain import (
    ArtifactBatchId,
    ArtifactId,
    ArtifactRevisionId,
    ArtifactRevisionStatus,
    Citation,
    CourseId,
    SessionId,
    SourceCommitment,
    SourceId,
    StudyArtifactKind,
)
from study_agent.domain._validation import JsonObject, JsonValue, require_text
from study_agent.domain.source import SourceKind
from study_agent.retrieval import SourceContentError
from study_agent.retrieval.content import CourseSourceContent, SourceRevisionRecord


class FlashcardReviewError(ValueError):
    """A flashcard cannot be rendered from its exact canonical evidence."""


@dataclass(frozen=True, slots=True)
class FlashcardSourceReference:
    """One readable source commitment resolved from the selected course."""

    source_id: SourceId
    source_revision_id: str
    source_title: str
    source_kind: SourceKind
    source_role: str
    source_is_current_revision: bool
    chunk_id: str
    section_path: tuple[str, ...]
    locator: str
    start_offset: int
    end_offset: int
    evidence: str

    def __post_init__(self) -> None:
        require_text(self.source_revision_id, "flashcard source revision id")
        require_text(self.source_title, "flashcard source title")
        require_text(self.source_role, "flashcard source role")
        require_text(self.chunk_id, "flashcard source chunk id")
        require_text(self.locator, "flashcard source locator")
        require_text(self.evidence, "flashcard source evidence")
        if not isinstance(self.source_kind, SourceKind):
            raise TypeError("flashcard source kind is invalid")
        if type(self.source_is_current_revision) is not bool:
            raise TypeError("flashcard source current-revision marker is invalid")
        if type(self.start_offset) is not int or type(self.end_offset) is not int:
            raise TypeError("flashcard source offsets must be integers")
        if self.start_offset < 0 or self.end_offset <= self.start_offset:
            raise ValueError("flashcard source offsets must describe a forward span")
        object.__setattr__(self, "section_path", tuple(self.section_path))
        if any(not isinstance(item, str) for item in self.section_path):
            raise TypeError("flashcard source section path must contain text")

    def to_json(self) -> JsonObject:
        return {
            "source_id": str(self.source_id),
            "source_revision_id": self.source_revision_id,
            "source_title": self.source_title,
            "source_kind": self.source_kind.value,
            "source_role": self.source_role,
            "source_is_current_revision": self.source_is_current_revision,
            "chunk_id": self.chunk_id,
            "section_path": self.section_path,
            "locator": self.locator,
            "start_offset": self.start_offset,
            "end_offset": self.end_offset,
            "evidence": self.evidence,
        }


@dataclass(frozen=True, slots=True)
class FlashcardReviewDto:
    """Closed public projection of one flashcard proposal.

    This DTO deliberately has no envelope, generic provenance, artifact
    payload, assessment field, expected response, or secret-bearing metadata.
    """

    revision_id: ArtifactRevisionId
    artifact_id: ArtifactId
    batch_id: ArtifactBatchId
    session_id: SessionId
    origin: str
    status: ArtifactRevisionStatus
    front: str
    answer_blocks: tuple[AnswerBlock, ...]
    rationale: str
    profile: JsonObject
    retrieval_form: str
    role: str
    cognitive_function: str | None
    morphology_family: str | None
    profile_selection: JsonObject | None
    source_references: tuple[FlashcardSourceReference, ...]
    media: tuple[JsonObject, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.revision_id, ArtifactRevisionId):
            raise TypeError("flashcard review revision id is invalid")
        if not isinstance(self.artifact_id, ArtifactId):
            raise TypeError("flashcard review artifact id is invalid")
        if not isinstance(self.batch_id, ArtifactBatchId):
            raise TypeError("flashcard review batch id is invalid")
        if not isinstance(self.session_id, SessionId):
            raise TypeError("flashcard review session id is invalid")
        if not isinstance(self.status, ArtifactRevisionStatus):
            raise TypeError("flashcard review status is invalid")
        require_text(self.origin, "flashcard review origin")
        require_text(self.front, "flashcard review front")
        require_text(self.rationale, "flashcard review rationale")
        require_text(self.retrieval_form, "flashcard review retrieval form")
        require_text(self.role, "flashcard review role")
        if self.cognitive_function is not None:
            require_text(self.cognitive_function, "flashcard review cognitive function")
        if self.morphology_family is not None:
            require_text(self.morphology_family, "flashcard review morphology family")
        blocks = tuple(self.answer_blocks)
        references = tuple(self.source_references)
        if not blocks or not all(isinstance(item, AnswerBlock) for item in blocks):
            raise ValueError("flashcard review requires typed answer blocks")
        if not references or not all(
            isinstance(item, FlashcardSourceReference) for item in references
        ):
            raise ValueError("flashcard review requires canonical source references")
        if self.profile_selection is not None:
            object.__setattr__(self, "profile_selection", _plain_object(self.profile_selection))
        object.__setattr__(self, "answer_blocks", blocks)
        object.__setattr__(self, "source_references", references)
        object.__setattr__(self, "media", tuple(self.media))

    def to_json(self) -> JsonObject:
        blocks: tuple[JsonObject, ...] = tuple(
            {
                "label": block.label,
                "text": block.text,
                "key_points": block.key_points,
            }
            for block in self.answer_blocks
        )
        return {
            "schema_version": 1,
            "revision_id": str(self.revision_id),
            "artifact_id": str(self.artifact_id),
            "batch_id": str(self.batch_id),
            "session_id": str(self.session_id),
            "origin": self.origin,
            "status": self.status.value,
            "proposal_status": self.status.value,
            "revision_status": self.status.value,
            "front": self.front,
            "prompt": self.front,
            "back": blocks,
            "answer_blocks": blocks,
            "rationale": self.rationale,
            "profile": _plain_object(self.profile),
            "retrieval_form": self.retrieval_form,
            "role": self.role,
            "cognitive_function": self.cognitive_function,
            "morphology_family": self.morphology_family,
            "profile_selection": (
                None if self.profile_selection is None else _plain_object(self.profile_selection)
            ),
            "media": self.media,
            "source_references": tuple(item.to_json() for item in self.source_references),
        }


def flashcard_review_dto(
    revision: ArtifactRevisionRecord,
    batch: ArtifactBatchRecord,
    course_id: CourseId,
    source_content: CourseSourceContent,
) -> FlashcardReviewDto:
    """Build a safe review DTO without serializing the generic artifact envelope."""

    if revision.kind is not StudyArtifactKind.FLASHCARD:
        raise FlashcardReviewError("only flashcard revisions have a review DTO")
    if batch.course_id != course_id:
        raise FlashcardReviewError("flashcard batch belongs to another course")
    content = revision.content.content
    if not isinstance(content, (HybridFlashcardContent, MorphologyFlashcardContent)):
        raise FlashcardReviewError("flashcard revision content codec is invalid")
    provenance = revision.provenance
    commitments = getattr(provenance, "source_commitments", ())
    records = _source_records(source_content, course_id)
    references = tuple(
        _source_reference(commitments[index], records, source_content)
        for index in content.source_commitment_indices
        if index < len(commitments)
    )
    if len(references) != len(content.source_commitment_indices):
        raise FlashcardReviewError("flashcard source commitment index is outside provenance")
    profile_selection = None
    if isinstance(provenance, GeneratedArtifactProvenance):
        selection = provenance.profile_selection
        if selection is not None:
            profile_selection = selection.to_json()
    if isinstance(content, HybridFlashcardContent):
        role = content.role.value
        family = None
        cognitive_function = None
    else:
        role = content.role.value
        family = content.family.value
        cognitive_function = content.cognitive_function.value
    media: tuple[JsonObject, ...] = tuple(
        {
            "source_commitment_index": item.source_commitment_index,
            "alt_text": item.alt_text,
        }
        for item in content.media
    )
    return FlashcardReviewDto(
        revision_id=revision.id,
        artifact_id=revision.artifact_id,
        batch_id=revision.batch_id,
        session_id=batch.session_id,
        origin=batch.origin.value,
        status=revision.status,
        front=content.prompt,
        answer_blocks=content.answer_blocks,
        rationale=content.rationale,
        profile=content.profile.to_json(),
        retrieval_form=content.retrieval_form.value,
        role=role,
        cognitive_function=cognitive_function,
        morphology_family=family,
        profile_selection=profile_selection,
        source_references=references,
        media=media,
    )


def _source_records(
    source_content: CourseSourceContent, course_id: CourseId
) -> dict[tuple[SourceId, str], SourceRevisionRecord]:
    records = tuple(source_content.catalog())
    if any(record.course_id != course_id for record in records):
        raise FlashcardReviewError("source catalog crossed the selected course boundary")
    result: dict[tuple[SourceId, str], SourceRevisionRecord] = {}
    for record in records:
        key = (record.source.source_id, str(record.source.revision_id))
        if key in result:
            raise FlashcardReviewError("source catalog contains duplicate revision identity")
        result[key] = record
    return result


def _plain_object(value: Mapping[str, JsonValue]) -> JsonObject:
    return cast(JsonObject, _plain_json(value))


def _plain_json(value: JsonValue) -> JsonValue:
    if isinstance(value, Mapping):
        return {key: _plain_json(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return tuple(_plain_json(item) for item in value)
    return value


def _source_reference(
    commitment: SourceCommitment,
    records: dict[tuple[SourceId, str], SourceRevisionRecord],
    source_content: CourseSourceContent,
) -> FlashcardSourceReference:
    source_id = commitment.source_id
    revision_id = commitment.revision_id
    chunk_id = commitment.chunk_id
    start = commitment.start_offset
    end = commitment.end_offset
    if not isinstance(source_id, SourceId):
        raise FlashcardReviewError("flashcard source commitment is malformed")
    key = (source_id, str(revision_id))
    record = records.get(key)
    if record is None:
        raise FlashcardReviewError("flashcard source revision is not canonical")
    chunk = next((item for item in record.chunks if item.chunk_id == chunk_id), None)
    if chunk is None:
        raise FlashcardReviewError("flashcard source chunk is not canonical")
    try:
        resolved = source_content.resolve(
            Citation(source_id, revision_id, chunk_id, start, end, "Cardine flashcard evidence")
        )
    except (LookupError, SourceContentError, ValueError) as error:
        raise FlashcardReviewError("flashcard source evidence cannot be resolved") from error
    if resolved.citation.source_id != source_id or resolved.citation.revision_id != revision_id:
        raise FlashcardReviewError("flashcard source evidence crossed its revision")
    if resolved.citation.chunk_id != chunk_id:
        raise FlashcardReviewError("flashcard source evidence crossed its chunk")
    return FlashcardSourceReference(
        source_id=source_id,
        source_revision_id=str(record.source.revision_id),
        source_title=record.source.title,
        source_kind=record.source.kind,
        source_role=record.source.source_role,
        source_is_current_revision=record.is_current_revision,
        chunk_id=str(chunk.chunk_id),
        section_path=chunk.section_path,
        locator=resolved.citation.locator,
        start_offset=resolved.citation.start_offset,
        end_offset=resolved.citation.end_offset,
        evidence=resolved.text,
    )


__all__ = [
    "FlashcardReviewDto",
    "FlashcardReviewError",
    "FlashcardSourceReference",
    "flashcard_review_dto",
]
