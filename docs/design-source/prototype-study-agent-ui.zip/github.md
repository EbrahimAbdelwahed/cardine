repo: EbrahimAbdelwahed/study-agent-harness
branch: main

## Last sync
date: 2026-07-27T13:47:01Z

### Updated in this project
- Prototipo webapp verticale per medicina (Cardine) costruito sui contratti tutor/harness.
- Stati del product shell (working, suspended, conflicted_context, needs_review, degraded, recovered) mappati sulla UI.
- Provenienza e eventi canonici ripresi dal trust boundary del reference host.
- Palette e vocabolario derivati da `src/study_agent/demo/browser.html`.

## Screen map
| Schermata (Cardine.dc.html) | File del repo |
| --- | --- |
| Oggi (Focus / Cruscotto) | docs/product-shell.md, src/study_agent/demo/product_shell.py |
| Sessione + pannello provenienza | docs/reference-tutor-host.md, src/study_agent/demo/browser.html |
| Fonti e revisioni immutabili | README.md (commit-then-index), specs/adaptive-tutor/README.md |
| Proposte (accetta/rifiuta) | specs/adaptive-tutor/README.md (TUT-04) |
| Ripasso + Ripasso mobile | specs/adaptive-tutor/README.md (TUT-07), product_shell.py (DueReview) |
| Verifiche con rubrica | specs/adaptive-tutor/README.md (TUT-05) |
| Evidenze per concetto | specs/adaptive-tutor/README.md (derived projections) |
| Piano verso l'esame | specs/adaptive-tutor/README.md |
| Conflitti di contesto | product_shell.py (_prioritize_status), specs/adaptive-tutor/README.md (ADR 4) |

## Note
Il repo non contiene una UI di prodotto: l'unica superficie browser è la reference page
`src/study_agent/demo/browser.html` (server stdlib, offline). Il prototipo estende quella
superficie, non la sostituisce.
